﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VelascoAguilar.Modelo
{
    class Variables
    {
        private Int32 peso;
        private Double altura;

        public Int32 Peso
        {
            get { return peso; }
            set { peso = value; }
        }

        public Double Altura 
        {
            get { return altura; }
            set { altura = value; }
        }

    }
}
